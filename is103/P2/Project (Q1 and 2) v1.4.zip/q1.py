# <Your Team ID>
# <Team members' names>

# replace the content of this function with your own algorithm
def schedule_q1(orders, number_trucks):
	truck_paths = []
	truck_paths.append([x[0] for x in orders])
	return truck_paths