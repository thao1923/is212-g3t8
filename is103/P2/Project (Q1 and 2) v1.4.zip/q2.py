# <Your registered name>
# <Your section>
import random

# replace the content of this function with your own algorithm
# truck_speed should always be 1
# number_trucks should be >=1
def schedule_q2(orders, airports, truck_speed, plane_speed, number_trucks):
    truck_paths = []
    truck_paths.append([x[0] for x in orders]) # only 1 truck is used
    
    # randomly insert pairs of airport IDs into truck_paths[0]
    for i in range(0, len(airports), 2):
        position = random.randint(0, len(truck_paths[0]))
        truck_paths[0].insert(position, airports[i+1][0])
        truck_paths[0].insert(position, airports[i][0])
    
    return truck_paths