There are 15 orders.csv files given:
001-005: random distribution of order locations
006-010: clustered distribution
011-015: mixture

There are 5 airports.csv files given, each with roughly 10 airports.
Try using different airports_xxx.csv files with different orders_xxx and parameters_xxx.csv files to come up with your own test cases.

Your algorithm should work well with different "combinations".
