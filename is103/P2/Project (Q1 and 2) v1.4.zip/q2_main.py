from utility import *
from q2 import schedule_q2
import copy

def legality_checking(truck_paths, order_list, airport_list, number_trucks):
	check_trucks(truck_paths, number_trucks)
	checking_all_order(truck_paths, order_list)
	legality_checking_airline_completeness(truck_paths)
	legality_checking_airline_capacity(truck_paths, airport_list)

# replace these parameters with different csv file locations
order_csv = "./dataset/orders_001.csv"
parameter_csv = "./dataset/parameters_001.csv"
airport_csv = "./dataset/airports_001.csv"

number_trucks, truck_speed, plane_speed = parameter_reader(parameter_csv)
orders = list_reader(order_csv)
airports = list_reader(airport_csv)
location_dict = location_dict_generation([orders, airports])

# these will b used on line 32. just in case your schedule_q2 modifies orders and airports. 
orders_clone = copy.deepcopy(orders)     # clone
airports_clone = copy.deepcopy(airports) # clone 

# call your function
truck_paths = schedule_q2(orders, airports, truck_speed, plane_speed, number_trucks) 

# check returned value
legality_checking(truck_paths, orders_clone, airports_clone, number_trucks)

# print score 
print("Score for q2 is : ", scoring_q2(truck_paths, location_dict, truck_speed, plane_speed)) # print your score (smaller is better)






